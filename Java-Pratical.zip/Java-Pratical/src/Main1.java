/* WAP to calculate the Area of a Circle, Area and Perimeter of rectangle, Area of Triangle. */

import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Calculate the Area of a Circle
        System.out.println("Enter the radius of the circle:");
        double radius = scanner.nextDouble();
        double areaCircle = Math.PI * Math.pow(radius, 2);
        System.out.println("Area of the Circle is: " + areaCircle);

        // Calculate the Area and Perimeter of a Rectangle
        System.out.println("Enter the length of the rectangle:");
        double length = scanner.nextDouble();
        System.out.println("Enter the width of the rectangle:");
        double width = scanner.nextDouble();
        double areaRectangle = length * width;
        double perimeterRectangle = 2 * (length + width);
        System.out.println("Area of the Rectangle is: " + areaRectangle);
        System.out.println("Perimeter of the Rectangle is: " + perimeterRectangle);

        // Calculate the Area of a Triangle
        System.out.println("Enter the base of the triangle:");
        double base = scanner.nextDouble();
        System.out.println("Enter the height of the triangle:");
        double height = scanner.nextDouble();
        double areaTriangle = 0.5 * base * height;
        System.out.println("Area of the Triangle is: " + areaTriangle);
    }
}
