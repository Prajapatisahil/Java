/* WAP to perform addition, multiplication, subtraction and division with Switch statement */

import java.util.Scanner;

public class Main10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first number:");
        double num1 = scanner.nextDouble();

        System.out.println("Enter the second number:");
        double num2 = scanner.nextDouble();

        System.out.println("Enter the operation (add, multiply, subtract, divide):");
        String operation = scanner.next();

        switch (operation) {
            case "add":
                double sum = num1 + num2;
                System.out.println("The sum is: " + sum);
                break;
            case "multiply":
                double product = num1 * num2;
                System.out.println("The product is: " + product);
                break;
            case "subtract":
                double difference = num1 - num2;
                System.out.println("The difference is: " + difference);
                break;
            case "divide":
                if (num2 != 0) {
                    double quotient = num1 / num2;
                    System.out.println("The quotient is: " + quotient);
                } else {
                    System.out.println("Error! Dividing by zero is not allowed.");
                }
                break;
            default:
                System.out.println("Error! Invalid operation. Please enter add, multiply, subtract, or divide.");
                break;
        }
    }
}
