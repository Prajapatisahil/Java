/* WAP to display 1-10 numbers, 20-30 numbers */

public class Main15 {
    public static void main(String[] args) {
        System.out.println("Numbers from 1 to 10:");
        for (int i = 1; i <= 10; i++) {
            System.out.println(i);
        }

        System.out.println("Numbers from 20 to 30:");
        for (int i = 20; i <= 30; i++) {
            System.out.println(i);
        }
    }
}
