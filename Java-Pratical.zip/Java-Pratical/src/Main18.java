/* WAP for finding sum of 1 to k. The number k should be read from the keyboard using Command line
argument. */

public class Main18 {
    public static void main(String[] args) {
        if (args.length > 0) {
            try {
                int k = Integer.parseInt(args[0]);
                int sum = 0;
                for (int i = 1; i <= k; i++) {
                    sum += i;
                }
                System.out.println("The sum of numbers from 1 to " + k + " is: " + sum);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input! Please enter an integer.");
            }
        } else {
            System.out.println("Please provide an integer as a command line argument.");
        }
    }
}
