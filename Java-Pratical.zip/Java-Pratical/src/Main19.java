/* WAP to print multiple of N from given range of unsigned integers. For example, if N=5 and range is [17, 45]
it prints 20, 25, 30, 35, 40, 45. Take input using Scanner class
 */

 import java.util.Scanner;

 public class Main19 {
     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
 
         System.out.println("Enter the value for N:");
         int N = scanner.nextInt();
 
         System.out.println("Enter the start of the range:");
         int start = scanner.nextInt();
 
         System.out.println("Enter the end of the range:");
         int end = scanner.nextInt();
 
         System.out.println("Multiples of " + N + " from " + start + " to " + end + ":");
         for (int i = start; i <= end; i++) {
             if (i % N == 0) {
                 System.out.println(i);
             }
         }
     }
 }
 