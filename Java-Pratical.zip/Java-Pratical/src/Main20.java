/* WAP to find sum of all integers greater than 100 & less than 200 and are divisible by 5 */

public class Main20 {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 105; i < 200; i += 5) {
            sum += i;
        }
        System.out.println("The sum is: " + sum);
    }
}
