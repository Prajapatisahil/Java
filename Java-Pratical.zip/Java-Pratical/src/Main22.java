/* WAP to find the sum of first N odd numbers */

import java.util.Scanner;

public class Main22 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the value for N:");
        int N = scanner.nextInt();

        int sum = 0;
        for (int i = 0, odd = 1; i < N; i++, odd += 2) {
            sum += odd;
        }

        System.out.println("The sum of the first " + N + " odd numbers is: " + sum);
    }
}
