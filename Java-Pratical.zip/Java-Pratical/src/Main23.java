/* WAP to find 1+3/5+5/7+7/9+… series. Print addition of first N part */

import java.util.Scanner;

public class Main23 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the value for N:");
        int N = scanner.nextInt();

        double sum = 0;
        for (int i = 0; i < N; i++) {
            double numerator = 2 * i + 1;
            double denominator = 2 * i + 3;
            sum += numerator / denominator;
        }

        System.out.printf("The sum of the first %d parts of the series is: %.2f\n", N, sum);
    }
}
