/* WAP to generate Fibonacci series of numbers */

import java.util.Scanner;

public class Main26 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of terms in the Fibonacci series:");
        int num = scanner.nextInt();

        long num1 = 0, num2 = 1;
        System.out.println("Fibonacci Series:");

        for (int i = 1; i <= num; ++i) {
            System.out.print(num1 + " ");

            // compute the next term
            long nextTerm = num1 + num2;
            num1 = num2;
            num2 = nextTerm;
        }
    }
}
