/* WAP to enter three subject marks, and calculate total, percentage of student and display the same in proper
format. */

import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the marks for the first subject:");
        double marks1 = scanner.nextDouble();

        System.out.println("Enter the marks for the second subject:");
        double marks2 = scanner.nextDouble();

        System.out.println("Enter the marks for the third subject:");
        double marks3 = scanner.nextDouble();

        double total = marks1 + marks2 + marks3;
        double percentage = (total / 300) * 100;

        System.out.println("Total Marks: " + total);
        System.out.printf("Percentage: %.2f%%\n", percentage);
    }
}
