/* WAP to find out sum of first and last digit of a given number */

import java.util.Scanner;

public class Main32 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a number:");
        int num = scanner.nextInt();
        int sum = sumOfFirstAndLastDigit(num);
        System.out.println("The sum of the first and last digit of " + num + " is " + sum);
    }

    public static int sumOfFirstAndLastDigit(int num) {
        int lastDigit = num % 10;
        int firstDigit = num;
        while (firstDigit >= 10) {
            firstDigit /= 10;
        }
        return firstDigit + lastDigit;
    }
}
