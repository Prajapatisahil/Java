/* 

WAP to print following pattern using loop statement for n row.

*
* *
* * *
* * * *
* * * * *
public class Pattern1 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}



1
1 3
1 3 5
1 3 5 7
public class Pattern2 {
    public static void main(String[] args) {
        int n = 4; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print((2 * j - 1) + " ");
            }
            System.out.println();
        }
    }
}



1
0 1
1 0 1
0 1 0 1
public class Pattern3 {
    public static void main(String[] args) {
        int n = 4; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print((i + j) % 2 + " ");
            }
            System.out.println();
        }
    }
}



1
2 3
4 5 6
7 8 9 10
public class Pattern4 {
    public static void main(String[] args) {
        int n = 4; // number of rows
        int num = 1;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(num + " ");
                num++;
            }
            System.out.println();
        }
    }
}



*
# #
* * *
# # # #
* * * * *
# # # # # #
* * * * * * *
public class Pattern5 {
    public static void main(String[] args) {
        int n = 7; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                if (i % 2 == 0) {
                    System.out.print("# ");
                } else {
                    System.out.print("* ");
                }
            }
            System.out.println();
        }
    }
}



1
2 2 
3 3 3
4 4 4 4 
5 5 5 5 5
* * * * *
* * * *
* * *
* *
*
// For Number
public class Pattern6 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}

// For *
public class Pattern7 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = n; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}



54321
4321
321
21
1
public class Pattern8 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = n; i >= 1; i--) {
            for (int j = i; j >= 1; j--) {
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }
}



1 2 3 4 5
2 3 4 5
3 4 5
4 5
5
public class Pattern9 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = 1; i <= n; i++) {
            for (int j = i; j <= n; j++) {
                System.out.print(j + " ");
            }
            System.out.println();
        }
    }
}



1
A B
1 2 3
A B C D
1 2 3 4 5
public class Pattern10 {
    public static void main(String[] args) {
        int n = 5; // number of rows
        for (int i = 1; i <= n; i++) {
            if (i % 2 != 0) {
                for (int j = 1; j <= i; j++) {
                    System.out.print(j + " ");
                }
            } else {
                for (char j = 'A'; j < 'A' + i; j++) {
                    System.out.print(j + " ");
                }
            }
            System.out.println();
        }
    }
}

*/