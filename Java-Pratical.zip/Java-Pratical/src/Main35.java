/* WAP to read 10 numbers from user and find Sum, Maximum, Minimum and Average of them */

import java.util.Scanner;

public class Main35 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;
        double average;

        for (int i = 1; i <= 10; i++) {
            System.out.println("Enter number " + i + ": ");
            int num = scanner.nextInt();
            sum += num;
            if (num > max) {
                max = num;
            }
            if (num < min) {
                min = num;
            }
        }

        average = (double) sum / 10;

        System.out.println("Sum: " + sum);
        System.out.println("Max: " + max);
        System.out.println("Min: " + min);
        System.out.println("Average: " + average);
    }
}
