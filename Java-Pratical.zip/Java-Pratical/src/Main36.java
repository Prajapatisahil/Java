/* WAP which declares array of 10 integers, enter data and sum all the elements which are even. Also find
maximum number from them. */

import java.util.Scanner;

public class Main36 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] numbers = new int[10];
        int sum = 0;
        int max = Integer.MIN_VALUE;

        for (int i = 0; i < 10; i++) {
            System.out.println("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
            if (numbers[i] % 2 == 0) {
                sum += numbers[i];
            }
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }

        System.out.println("Sum of even numbers: " + sum);
        System.out.println("Max number: " + max);
    }
}
