/* WAP to accept array of N integers and find Largest odd number as well as largest even number and display
them. */

import java.util.Scanner;

public class Main37 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int N = scanner.nextInt();
        int[] numbers = new int[N];
        int largestEven = Integer.MIN_VALUE;
        int largestOdd = Integer.MIN_VALUE;

        for (int i = 0; i < N; i++) {
            System.out.println("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
            if (numbers[i] % 2 == 0 && numbers[i] > largestEven) {
                largestEven = numbers[i];
            } else if (numbers[i] % 2 != 0 && numbers[i] > largestOdd) {
                largestOdd = numbers[i];
            }
        }

        System.out.println("Largest even number: " + largestEven);
        System.out.println("Largest odd number: " + largestOdd);
    }
}
