/* WAP read in an array of integers and print its elements in reverse order. */

import java.util.Scanner;

public class Main38 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the size of the array: ");
        int N = scanner.nextInt();
        int[] numbers = new int[N];

        for (int i = 0; i < N; i++) {
            System.out.println("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        System.out.println("Elements in reverse order: ");
        for (int i = N - 1; i >= 0; i--) {
            System.out.println(numbers[i]);
        }
    }
}
