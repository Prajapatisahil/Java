/* WAP to convert days into months and days. */

import java.util.Scanner;

public class Main4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of days:");
        int days = scanner.nextInt();

        // Assuming each month has approximately 30 days
        int months = days / 30;
        int remainingDays = days % 30;

        System.out.println(days + " days is approximately " + months + " month(s) and " + remainingDays + " day(s).");
    }
}
