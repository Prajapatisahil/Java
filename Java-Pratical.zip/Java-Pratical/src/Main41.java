/* WAP to find the minimum value from the array of 3 x 3. */

public class Main41 {
    public static void main(String[] args) {
        int[][] matrix = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int min = findMin(matrix);
        System.out.println("The minimum element is: " + min);
    }

    public static int findMin(int[][] matrix) {
        int min = Integer.MAX_VALUE;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (matrix[i][j] < min) {
                    min = matrix[i][j];
                }
            }
        }

        return min;
    }
}
