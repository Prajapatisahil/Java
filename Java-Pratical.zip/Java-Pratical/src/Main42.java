/* WAP to count number of positive, negative and zero elements from 3 x 3 matrix */

public class Main42 {
    public static void main(String[] args) {
        int[][] matrix = {{1, -2, 0}, {4, -5, 0}, {7, 8, -9}};
        countElements(matrix);
    }

    public static void countElements(int[][] matrix) {
        int positiveCount = 0;
        int negativeCount = 0;
        int zeroCount = 0;

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (matrix[i][j] > 0) {
                    positiveCount++;
                } else if (matrix[i][j] < 0) {
                    negativeCount++;
                } else {
                    zeroCount++;
                }
            }
        }

        System.out.println("Number of positive elements: " + positiveCount);
        System.out.println("Number of negative elements: " + negativeCount);
        System.out.println("Number of zero elements: " + zeroCount);
    }
}
