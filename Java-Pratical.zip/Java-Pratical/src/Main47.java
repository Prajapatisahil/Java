/* WAP to concatenate two strings without using built in function.  */

public class Main47 {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        String result = "";

        for (int i = 0; i < str1.length(); i++) {
            result += str1.charAt(i);
        }

        for (int i = 0; i < str2.length(); i++) {
            result += str2.charAt(i);
        }

        System.out.println("Concatenated string: " + result);
    }
}
