/* WAP that converts Fahrenheit temperature to centigrade and vis-a-versa Centigrade =(5* (fahr.-32))/9 */

import java.util.Scanner;

public class Main5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the temperature in Fahrenheit:");
        double fahrenheit = scanner.nextDouble();
        double centigrade = (5 * (fahrenheit - 32)) / 9;
        System.out.printf("Temperature in Centigrade: %.2f°C\n", centigrade);

        System.out.println("Enter the temperature in Centigrade:");
        centigrade = scanner.nextDouble();
        fahrenheit = (centigrade * 9 / 5) + 32;
        System.out.printf("Temperature in Fahrenheit: %.2f°F\n", fahrenheit);
    }
}
