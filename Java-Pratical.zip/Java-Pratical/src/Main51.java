/* Write a method with the following header to display an integer in reverse order:
public static void reverse(int number)
For example, reverse(3456) displays 6543. Write a test program that prompts the user to enter an integer and
displays its reversal. */

import java.util.Scanner;

public class Main51 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter an integer: ");
        int number = scanner.nextInt();
        reverse(number);
    }

    public static void reverse(int number) {
        while (number != 0) {
            System.out.print(number % 10);
            number = number / 10;
        }
        System.out.println();
    }
}
