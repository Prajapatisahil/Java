/* WAP to calculate nCr using recursion. nCr = n! / (r! * (n-r)!) */

public class Main53 {
    public static void main(String[] args) {
        int n = 5;
        int r = 3;
        System.out.println("nCr for n=" + n + " and r=" + r + " is " + nCr(n, r));
    }

    public static int nCr(int n, int r) {
        return factorial(n) / (factorial(r) * factorial(n - r));
    }

    public static int factorial(int n) {
        if (n == 0)
            return 1;
        else
            return n * factorial(n - 1);
    }
}
