/* WAP to find sum of digit of given number using recursion.  */

public class Main55 {
    public static void main(String[] args) {
        int number = 12345; // Change this to the number you want to find the sum of digits for
        System.out.println("The sum of the digits of " + number + " is " + sumOfDigits(number));
    }

    public static int sumOfDigits(int number) {
        if (number == 0) {
            return 0;
        } else {
            return number % 10 + sumOfDigits(number / 10);
        }
    }
}
