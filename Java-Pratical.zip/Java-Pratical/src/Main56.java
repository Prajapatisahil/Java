/* 
Write a program which takes five numbers as command line argument from user, store them in one
dimensional array and display count of negative numbers.
*/

public class Main56 {
    public static void main(String[] args) {
        if (args.length != 5) {
            System.out.println("Please enter exactly 5 numbers.");
            return;
        }

        int[] numbers = new int[5];
        int negativeCount = 0;

        for (int i = 0; i < 5; i++) {
            numbers[i] = Integer.parseInt(args[i]);
            if (numbers[i] < 0) {
                negativeCount++;
            }
        }

        System.out.println("Number of negative numbers: " + negativeCount);
    }
}
