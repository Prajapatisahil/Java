/* Write a program that creates and initializes a four integer element array. Calculate and display the average of
its values. */

public class Main57 {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40};
        int sum = 0;

        for (int i = 0; i < array.length; i++) {
            sum += array[i];
        }

        double average = (double) sum / array.length;
        System.out.println("The average of the array elements is: " + average);
    }
}
