/* Write a program that prompts the user to enter the number of students, the students’ names, and their scores,
and prints student names in decreasing order of their scores. */

import java.util.*;

public class Main58 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of students: ");
        int numberOfStudents = scanner.nextInt();
        scanner.nextLine(); // consume newline left-over

        Map<String, Integer> scores = new HashMap<>();

        for (int i = 0; i < numberOfStudents; i++) {
            System.out.println("Enter the name of student " + (i + 1) + ": ");
            String name = scanner.nextLine();
            System.out.println("Enter the score of student " + (i + 1) + ": ");
            int score = scanner.nextInt();
            scanner.nextLine(); // consume newline left-over

            scores.put(name, score);
        }

        scores.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .forEach(entry -> System.out.println(entry.getKey() + ": " + entry.getValue()));
    }
}
