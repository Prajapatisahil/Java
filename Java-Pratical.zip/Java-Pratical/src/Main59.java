/* Write a program that creates an integer array and then uses a for loop to check whether the array is sorted
from smallest to largest. If so, it prints “sorted” otherwise it prints “Not sorted” */

public class Main59 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5}; // Change this to the array you want to check

        boolean isSorted = true;
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] > array[i + 1]) {
                isSorted = false;
                break;
            }
        }

        if (isSorted) {
            System.out.println("Sorted");
        } else {
            System.out.println("Not sorted");
        }
    }
}
