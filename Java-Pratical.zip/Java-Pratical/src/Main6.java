/* WAP to swap two numbers with and without using temporary variable */

// Using a temporary variable
import java.util.Scanner;

public class Main6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first number:");
        int num1 = scanner.nextInt();

        System.out.println("Enter the second number:");
        int num2 = scanner.nextInt();

        // Using a temporary variable
        int temp = num1;
        num1 = num2;
        num2 = temp;

        System.out.println("After swapping, first number is " + num1 + " and second number is " + num2);
    }
}


// Without using a temporary variable
/* 
import java.util.Scanner;

public class Main6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first number:");
        int num1 = scanner.nextInt();

        System.out.println("Enter the second number:");
        int num2 = scanner.nextInt();

        // Without using a temporary variable
        num1 = num1 + num2;
        num2 = num1 - num2;
        num1 = num1 - num2;

        System.out.println("After swapping, first number is " + num1 + " and second number is " + num2);
    }
}
*/