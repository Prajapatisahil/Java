/* Write a java program to calculate total and average to five values. Pass input values as constructor
parameter. */

public class Main60 {
    private int[] values;

    public Main60(int value1, int value2, int value3, int value4, int value5) {
        this.values = new int[]{value1, value2, value3, value4, value5};
    }

    public int getTotal() {
        int total = 0;
        for (int value : this.values) {
            total += value;
        }
        return total;
    }

    public double getAverage() {
        return (double) getTotal() / this.values.length;
    }

    public static void main(String[] args) {
        Main60 calculator = new Main60(1, 2, 3, 4, 5);
        System.out.println("Total: " + calculator.getTotal());
        System.out.println("Average: " + calculator.getAverage());
    }
}
