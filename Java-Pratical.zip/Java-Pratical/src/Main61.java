/* Write a class named Rectangle to represent a rectangle. It contains following members: DATA: width(double) and 
height (Double) that specify the width and height of the rectangle. Methods:
1. A no-arg constructor that creates a default rectangle.
2. A constructor that creates a rectangle with the specified width and height.
3. A method named getArea() that returns the area of this rectangle.
4. A method named getPerimeter() that returns the perimeter. */

public class Main61 {
    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle(5.0, 7.0);
        System.out.println("Area: " + rectangle.getArea());
        System.out.println("Perimeter: " + rectangle.getPerimeter());
    }
}

class Rectangle {
    private double width;
    private double height;

    // No-arg constructor that creates a default rectangle
    public Rectangle() {
        this.width = 1.0;
        this.height = 1.0;
    }

    // Constructor that creates a rectangle with the specified width and height
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    // Method that returns the area of this rectangle
    public double getArea() {
        return width * height;
    }

    // Method that returns the perimeter of this rectangle
    public double getPerimeter() {
        return 2 * (width + height);
    }
}