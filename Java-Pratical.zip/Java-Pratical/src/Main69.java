/* Declare a class called book having author_name as private data member. Extend book class to have two sub classes 
called book_publication&paper_publication. Each of these classes have private member called title. Write a complete 
program to show usage of dynamic method dispatch (dynamic polymorphism) to display book or paper publications 
of given author. Use command line arguments for inputting data.  */

abstract class Book {
    private String authorName;

    public Book(String authorName) {
        this.authorName = authorName;
    }

    public String getAuthorName() {
        return authorName;
    }

    abstract String getTitle();
}

class BookPublication extends Book {
    private String title;

    public BookPublication(String authorName, String title) {
        super(authorName);
        this.title = title;
    }

    @Override
    String getTitle() {
        return title;
    }
}

class PaperPublication extends Book {
    private String title;

    public PaperPublication(String authorName, String title) {
        super(authorName);
        this.title = title;
    }

    @Override
    String getTitle() {
        return title;
    }
}

public class Main69 {
    public static void main(String[] args) {
        Book bookPublication = new BookPublication(args[0], args[1]);
        Book paperPublication = new PaperPublication(args[2], args[3]);

        System.out.println("Book Publication: Author - " + bookPublication.getAuthorName() + ", Title - " + bookPublication.getTitle());
        System.out.println("Paper Publication: Author - " + paperPublication.getAuthorName() + ", Title - " + paperPublication.getTitle());
    }
}
