/* WAP to determine a given number is ‘odd’ or ‘even’ and print the following message “Number is ODD” or
“Number is Even” (i) Without using else option. (ii) With else option */

// Without using else option
import java.util.Scanner;

public class Main7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a number:");
        int num = scanner.nextInt();

        // Without using else option
        if (num % 2 == 0) {
            System.out.println("Number is Even");
        }
        if (num % 2 != 0) {
            System.out.println("Number is ODD");
        }
    }
}


// With else option
/* 
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a number:");
        int num = scanner.nextInt();

        // With else option
        if (num % 2 == 0) {
            System.out.println("Number is Even");
        } else {
            System.out.println("Number is ODD");
        }
    }
}
*/