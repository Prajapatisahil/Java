/* Write a program to replace all “word1” by “word2” from a file1, and output is written to file2 file and display the no. 
of replacement. */

import java.io.*;
import java.nio.file.*;

public class Main72 {
    public static void main(String[] args) {
        String filePath = "file1.txt";
        String outputFilePath = "file2.txt";
        String word1 = "word1";
        String word2 = "word2";

        try {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            int count = content.length() - content.replace(word1, "").length();
            count /= word1.length();

            content = content.replace(word1, word2);
            Files.write(Paths.get(outputFilePath), content.getBytes());

            System.out.println("Number of replacements: " + count);
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
