/* Write a program that counts the no. of words in a text file. The file name is passed as a command line argument. The 
program should check whether the file exists or not. The words in the file are separated by white space characters.
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main73 {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Please provide a file name as a command line argument.");
            return;
        }

        String fileName = args[0];
        File file = new File(fileName);

        if (!file.exists()) {
            System.out.println("The file " + fileName + " does not exist.");
            return;
        }

        try (Scanner scanner = new Scanner(file)) {
            int wordCount = 0;
            while (scanner.hasNext()) {
                scanner.next();
                wordCount++;
            }
            System.out.println("The file contains " + wordCount + " words.");
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
    }
}
