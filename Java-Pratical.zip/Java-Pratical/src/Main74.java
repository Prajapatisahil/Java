/*
Write a program to read the content of a file into a character array and write it into another file. Get names of the files 
from command line
*/

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Main74 {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Please provide the source and destination file names as command line arguments.");
            return;
        }

        String sourceFileName = args[0];
        String destinationFileName = args[1];

        try (FileReader reader = new FileReader(sourceFileName);
             FileWriter writer = new FileWriter(destinationFileName)) {

            char[] buffer = new char[1024];
            int length;

            while ((length = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, length);
            }

            System.out.println("File has been copied successfully.");

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
