/* Read employee salary and calculate the income tax based on 10% of income and store it in tax.txt file for five 
different employees. */

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main75 {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in);
             FileWriter writer = new FileWriter("tax.txt")) {

            for (int i = 1; i <= 5; i++) {
                System.out.println("Enter the salary of employee " + i + ": ");
                double salary = scanner.nextDouble();
                double tax = salary * 0.1;

                writer.write("Employee " + i + ": Salary = " + salary + ", Tax = " + tax + "\n");
            }

            System.out.println("Income tax for all employees has been written to tax.txt.");

        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
