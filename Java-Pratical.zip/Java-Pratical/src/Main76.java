/* The abstract Vegetable class has three subclasses named Potato, Brinjal and Tomato. Write an application that 
demonstrates how to establish this class hierarchy. Declare one instance variable of type String that indicates the 
color of a vegetable. Create and display instances of these objects. Override the toString() method of Object to return 
a string with the name of the vegetable and its color. */

abstract class Vegetable {
    protected String color;

    public Vegetable(String color) {
        this.color = color;
    }

    @Override
    public abstract String toString();
}

class Potato extends Vegetable {
    public Potato(String color) {
        super(color);
    }

    @Override
    public String toString() {
        return "Potato color: " + color;
    }
}

class Brinjal extends Vegetable {
    public Brinjal(String color) {
        super(color);
    }

    @Override
    public String toString() {
        return "Brinjal color: " + color;
    }
}

class Tomato extends Vegetable {
    public Tomato(String color) {
        super(color);
    }

    @Override
    public String toString() {
        return "Tomato color: " + color;
    }
}

public class Main76 {
    public static void main(String[] args) {
        Vegetable potato = new Potato("brown");
        Vegetable brinjal = new Brinjal("purple");
        Vegetable tomato = new Tomato("red");

        System.out.println(potato);
        System.out.println(brinjal);
        System.out.println(tomato);
    }
}
