/* Write a program that illustrates interface inheritance. Interface P is extended by P1 And P2. Interface P12 inherits 
from both P1 and P2.Each interface declares one constant and one method. Class Q implements P12.Instantiate Q and 
invokes each of its methods. Each method displays one of the constants. */

interface P {
    int P_CONST = 1;
    void pMethod();
}

interface P1 extends P {
    int P1_CONST = 2;
    void p1Method();
}

interface P2 extends P {
    int P2_CONST = 3;
    void p2Method();
}

interface P12 extends P1, P2 {
    int P12_CONST = 4;
    void p12Method();
}

class Q implements P12 {
    public void pMethod() {
        System.out.println("pMethod: " + P_CONST);
    }

    public void p1Method() {
        System.out.println("p1Method: " + P1_CONST);
    }

    public void p2Method() {
        System.out.println("p2Method: " + P2_CONST);
    }

    public void p12Method() {
        System.out.println("p12Method: " + P12_CONST);
    }
}

public class Main77 {
    public static void main(String[] args) {
        Q q = new Q();
        q.pMethod();
        q.p1Method();
        q.p2Method();
        q.p12Method();
    }
}
