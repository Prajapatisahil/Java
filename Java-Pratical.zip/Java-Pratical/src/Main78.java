/* The Transport interface declares a deliver() method. The abstract class Animal is the superclass of the Tiger, Camel, 
Deer and Donkey classes. The Transport interface is implemented by the Camel and Donkey classes. Write a test 
program that initialize an array of four Animal objects. If the object implements the Transport interface, the deliver() 
method is invoked. */

interface Transport {
    void deliver();
}

abstract class Animal {
    abstract void display();
}

class Tiger extends Animal {
    void display() {
        System.out.println("This is a Tiger");
    }
}

class Deer extends Animal {
    void display() {
        System.out.println("This is a Deer");
    }
}

class Camel extends Animal implements Transport {
    void display() {
        System.out.println("This is a Camel");
    }

    public void deliver() {
        System.out.println("Camel delivering");
    }
}

class Donkey extends Animal implements Transport {
    void display() {
        System.out.println("This is a Donkey");
    }

    public void deliver() {
        System.out.println("Donkey delivering");
    }
}

public class Main78 {
    public static void main(String[] args) {
        Animal[] animals = {new Tiger(), new Deer(), new Camel(), new Donkey()};

        for (Animal animal : animals) {
            animal.display();
            if (animal instanceof Transport) {
                ((Transport) animal).deliver();
            }
        }
    }
}
