/* Write a abstract class named Person and its two subclasses named student and Employee. A person has a name, 
address, phone number and email address. A student has enrollment course. An Employee has an office, salary, and 
designation. Define constructors and methods for input and display for both classes. Define constructor and methods 
for input and display for both classes. Write a main program to give demonstration of all. */

abstract class Person {
    protected String name;
    protected String address;
    protected String phoneNumber;
    protected String emailAddress;

    public Person(String name, String address, String phoneNumber, String emailAddress) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
    }

    public abstract void display();
}

class Student extends Person {
    private String enrollmentCourse;

    public Student(String name, String address, String phoneNumber, String emailAddress, String enrollmentCourse) {
        super(name, address, phoneNumber, emailAddress);
        this.enrollmentCourse = enrollmentCourse;
    }

    public void display() {
        System.out.println("Student Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Enrollment Course: " + enrollmentCourse);
    }
}

class Employee extends Person {
    private String office;
    private double salary;
    private String designation;

    public Employee(String name, String address, String phoneNumber, String emailAddress, String office, double salary, String designation) {
        super(name, address, phoneNumber, emailAddress);
        this.office = office;
        this.salary = salary;
        this.designation = designation;
    }

    public void display() {
        System.out.println("Employee Name: " + name);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Email Address: " + emailAddress);
        System.out.println("Office: " + office);
        System.out.println("Salary: " + salary);
        System.out.println("Designation: " + designation);
    }
}

public class Main79 {
    public static void main(String[] args) {
        Student student = new Student("John Doe", "123 Street", "1234567890", "john@example.com", "Computer Science");
        Employee employee = new Employee("Jane Doe", "456 Avenue", "0987654321", "jane@example.com", "XYZ Office", 50000, "Manager");

        student.display();
        System.out.println();
        employee.display();
    }
}
