/* WAP to print grade of a student using following rules:
Percentage >70 means Grade A
Percentage 60-70 means Grade B
Percentage 50-60 means Grade C
Percentage <50 means Grade F */

import java.util.Scanner;

public class Main9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the percentage:");
        double percentage = scanner.nextDouble();

        if (percentage > 70) {
            System.out.println("Grade A");
        } else if (percentage >= 60) {
            System.out.println("Grade B");
        } else if (percentage >= 50) {
            System.out.println("Grade C");
        } else {
            System.out.println("Grade F");
        }
    }
}
